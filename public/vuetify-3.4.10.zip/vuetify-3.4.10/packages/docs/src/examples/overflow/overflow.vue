<template>
  <v-row>
    <v-col cols="auto">
      <v-card width="200" height="200" class="overflow-auto">
        <v-card-text>
          <h3>Overflow Auto</h3>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis
          facilis dicta esse molestias vero hic laudantium provident nisi eos
          quasi iusto alias sequi, aut aliquid voluptatibus commodi! Minima, eum
          voluptates?
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="auto">
      <v-card width="200" height="200" class="overflow-hidden">
        <v-card-text>
          <h3>Overflow Hidden</h3>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis
          facilis dicta esse molestias vero hic laudantium provident nisi eos
          quasi iusto alias sequi, aut aliquid voluptatibus commodi! Minima, eum
          voluptates?
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="auto">
      <v-card width="200" height="200" class="overflow-visible">
        <v-card-text>
          <h3>Overflow visible</h3>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis
          facilis dicta esse molestias vero hic laudantium provident nisi eos
          quasi iusto alias sequi, aut aliquid voluptatibus commodi! Minima, eum
          voluptates?
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>
</template>
