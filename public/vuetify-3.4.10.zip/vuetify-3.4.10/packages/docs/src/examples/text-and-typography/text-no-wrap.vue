<template>
  <div
    class="text-no-wrap bg-secondary"
    style="width: 8rem;"
  >
    This text should overflow the parent.
  </div>
</template>
