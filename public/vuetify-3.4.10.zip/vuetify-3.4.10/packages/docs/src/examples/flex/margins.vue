<template>
  <div>
    <v-sheet class="d-flex mb-6 bg-surface-variant">
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
    </v-sheet>

    <v-sheet class="d-flex mb-6 bg-surface-variant">
      <v-sheet class="ma-2 pa-2 me-auto">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
    </v-sheet>

    <v-sheet class="d-flex mb-6 bg-surface-variant">
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
    </v-sheet>
  </div>
</template>
