<template>
  <div>
    <v-sheet
      class="d-flex align-start flex-column mb-6 bg-surface-variant"
      height="200"
    >
      <v-sheet class="ma-2 pa-2 mb-auto">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
    </v-sheet>

    <v-sheet
      class="d-flex align-end flex-column bg-surface-variant"
      height="200"
    >
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>
      <v-sheet class="ma-2 pa-2 mt-auto">Flex item</v-sheet>
    </v-sheet>
  </div>
</template>
