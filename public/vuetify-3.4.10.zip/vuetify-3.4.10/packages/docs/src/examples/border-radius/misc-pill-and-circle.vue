<template>
  <div class="d-flex justify-space-around">
    <div
      class="px-10 bg-secondary rounded-pill"
    >
    </div>
    <div
      class="pa-6 bg-secondary rounded-circle d-inline-block"
    ></div>
  </div>
</template>
