<template>
  <div class="d-flex justify-space-around">
    <div class="pa-4 text-center bg-secondary rounded-0">
      .rounded-0
    </div>

    <div class="pa-4 text-center bg-secondary rounded-xl rounded-be-0">
      .rounded-xl .rounded-be-0
    </div>
  </div>
</template>
