<template>
  <div>
    <div class="d-inline pa-2 bg-deep-purple">
      d-inline
    </div>
    <div class="d-inline pa-2 bg-black">
      d-inline
    </div>
  </div>
</template>
