<template>
  <div>
    <v-card
      class="mx-auto"
      height="100"
      max-width="200"
      color="secondary"
    ></v-card>
    <v-card
      class="mt-n12 mx-auto"
      elevation="12"
      height="200"
      max-width="300"
      color="secondary"
    >
      <v-card-text>This card has negative top margin applied</v-card-text>
    </v-card>
  </div>
</template>
