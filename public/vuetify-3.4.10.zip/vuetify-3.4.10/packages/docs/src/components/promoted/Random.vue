<template>
  <vuetify class="mb-5" />
</template>

<script setup>
  //
</script>
