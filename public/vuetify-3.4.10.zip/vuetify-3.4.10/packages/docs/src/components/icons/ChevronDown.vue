<template>
  <v-icon
    class="hidden-sm-and-down"
    size="14"
    icon="mdi-chevron-down"
  />
</template>

<script setup>
  //
</script>
