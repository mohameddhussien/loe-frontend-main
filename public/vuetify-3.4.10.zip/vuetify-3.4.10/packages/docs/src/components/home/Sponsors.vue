<template>
  <v-sheet
    id="home-sponsors"
    class="mx-auto pa-3"
    color="transparent"
    max-width="700"
  >
    <v-responsive min-height="500">
      <v-row
        dense
        justify="center"
      >
        <v-col
          v-for="sponsor in sponsors"
          :key="sponsor.slug"
          class="d-flex align-center justify-center"
          cols="auto"
        >
          <sponsor-card
            :comfortable="Number(sponsor.metadata.tier) === 2"
            :compact="Number(sponsor.metadata.tier) > 2"
            :sponsor="sponsor"
            v-bind="$attrs"
            :width="Number(sponsor.metadata.tier) > 1 && smAndDown ? 90 : undefined"
          />
        </v-col>
      </v-row>
    </v-responsive>

    <br>
    <br>

    <sponsor-link size="large" />
  </v-sheet>
</template>

<script setup>
  // Components
  import SponsorCard from '@/components/sponsor/Card.vue'
  import SponsorLink from '@/components/sponsor/Link.vue'

  // Composables
  import { useDisplay } from 'vuetify'
  import { useSponsorsStore } from '@/store/sponsors'

  // Utilities
  import { computed } from 'vue'

  const { smAndDown } = useDisplay()
  const sponsorStore = useSponsorsStore()

  const sponsors = computed(() => {
    return Object.values(sponsorStore.byTier)
      .reduce((tiers, tier) => {
        for (const sponsor of tier) {
          if (Number(sponsor.metadata.tier) < 0) continue

          tiers.push(sponsor)
        }

        return tiers
      }, [])
  })
</script>

<script>
  export default {
    inheritAttrs: false,
  }
</script>
