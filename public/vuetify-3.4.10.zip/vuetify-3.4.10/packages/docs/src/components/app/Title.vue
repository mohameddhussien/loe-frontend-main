<template>
  <app-headline size="subtitle-2" weight="black" />
</template>

<script setup>
  //
</script>
